using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;

namespace Menhelyes_Selenium_Test
{
    public class Tests
    {
        IWebDriver driver;

        [SetUp]
        public void Setup()
        {
            driver = new FirefoxDriver();
        }

        [Test]
        public void landingPage_Titles()
        {


            string[] aloldalURLek = 
            {   "http://127.0.0.1/menhelyes/public/",
                    "http://127.0.0.1/menhelyes/public/menhelyek",
                    "http://127.0.0.1/menhelyes/public/allatok",
                    "http://127.0.0.1/menhelyes/public/kapcsolat",
                    "http://127.0.0.1/menhelyes/public/login",
                    "http://127.0.0.1/menhelyes/public/register",
                    "http://127.0.0.1/menhelyes/public/gyik",
                    "http://127.0.0.1/menhelyes/public/hirlevel"
            };

            string[] ElvartoldalCim = { "F�oldal", "Menhelyek", "�llatok", "Kapcsolat", "Bejelentkez�s", "Regisztr�ci�", "GY.I.K.", "H�rlev�l" };
            string elvartCim = "";
            string valosCim = "";
            int kulcs = 0;
            foreach (string url in  aloldalURLek) { 
            
                driver.Navigate().GoToUrl(url);
                valosCim = driver.Title;
                elvartCim = ElvartoldalCim[kulcs];
                Assert.AreEqual(elvartCim, valosCim);
                kulcs++;
            };
                
        }
        
        [TearDown]
        public void TearDown()
        {
            driver.Close();
        }
    }
}